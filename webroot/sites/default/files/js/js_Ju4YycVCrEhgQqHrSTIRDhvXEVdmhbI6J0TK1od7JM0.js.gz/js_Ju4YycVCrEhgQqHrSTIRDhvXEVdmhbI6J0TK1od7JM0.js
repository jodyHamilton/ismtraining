(function ($, Drupal) {

  Drupal.behaviors.mailfishUserTime = {
    attach: function attach(context) {
      
      console.log('Hello World!');

    }
  };
})(jQuery, Drupal);;
